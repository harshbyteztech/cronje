import 'package:flutter/material.dart';

const Color mainColor = Color(0xff282828);
const Color blackColor = Color(0xff000000);
const Color whiteColor = Color(0xffffffff);
const Color bgColor = Color(0xffF7F5F1);
const Color textColor = Color(0xffAA9670);
const Color textHint = Color(0xff9C9C9C);
