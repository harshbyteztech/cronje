class AppDimens {
  static const double medium_font = 16.0;
  static const double large_font = 18.0;
  static const double extra_large_font = 25.0;
  static const double indicator_size = 12.0;
  static const double default_font = 14.0;
  static const double full_display = 100;
}
